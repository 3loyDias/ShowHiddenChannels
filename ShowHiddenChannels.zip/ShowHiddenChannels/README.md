This plugin offers 2 versions one [with](https://https://github.com/3loyDias/ShowHiddenChannels) a custom library, at the moment the one without it requires a quick reload of the plugin every restart (I'm working on it), you are currently on the WITH LIBRARY branch

# ShowHiddenChannels
<p align="left">
    <b>Simple plugin ShowHiddenChannels.</b><br>
    A plugin which displays all hidden Channels, which can't be accessed due to Role Restrictions, this won't allow you to read them (impossible)
</p>

### Additional Features

- Removed Forced Auto Update (This shouldn't even have been here in the first place)
- Added a DevTool toggleable setting (Instead of relying on the developer discord id)
- Removed Cryptocurrency links (I don't support crypto)

